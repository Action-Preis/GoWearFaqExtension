# GoWearFaqExtension

Dieses Plugin erweitert das PlentyShop-Template um eine FAQ-Darstellung im Artikel – im Akkordeon-Stil.
